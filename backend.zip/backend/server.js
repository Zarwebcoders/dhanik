require('dotenv').config({ path: './backend/.env' });
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

// Connect to Database
connectDB();

// Temporary Migration: Promote admin users and sync referrals
const User = require('./models/User');

const syncReferrals = async () => {
    try {
        console.log('🔄 Syncing referral data...');
        const allUsers = await User.find({});

        // Reset all referral arrays first to ensure clean state
        await User.updateMany({}, {
            $set: {
                'referrals.level1': [],
                'referrals.level2': [],
                'referrals.level3': []
            }
        });

        for (const user of allUsers) {
            if (user.referredBy) {
                const cleanRefL1 = user.referredBy.trim();
                const sponsorL1 = await User.findOne({ referralId: cleanRefL1 });
                if (sponsorL1) {
                    sponsorL1.referrals.level1.push(user._id);
                    await sponsorL1.save();

                    if (sponsorL1.referredBy) {
                        const cleanRefL2 = sponsorL1.referredBy.trim();
                        const sponsorL2 = await User.findOne({ referralId: cleanRefL2 });
                        if (sponsorL2) {
                            sponsorL2.referrals.level2.push(user._id);
                            await sponsorL2.save();

                            if (sponsorL2.referredBy) {
                                const cleanRefL3 = sponsorL2.referredBy.trim();
                                const sponsorL3 = await User.findOne({ referralId: cleanRefL3 });
                                if (sponsorL3) {
                                    sponsorL3.referrals.level3.push(user._id);
                                    await sponsorL3.save();
                                }
                            }
                        }
                    }
                }
            }
        }
        console.log('✅ Referral data synced successfully');
    } catch (err) {
        console.error('Sync error:', err);
    }
};

const runMigrations = async () => {
    try {
        const adminEmails = ['admin1@gmail.com', 'admin@gmail.com'];
        await User.updateMany(
            { email: { $in: adminEmails } },
            { $set: { isAdmin: 1 } }
        );
        console.log('✅ Registered admins promoted successfully');

        await syncReferrals();
    } catch (err) {
        console.error('Migration error:', err);
    }
};
runMigrations();

const app = express();

// Middleware
const corsOptions = {
    origin: [
        'https://dhanik.in',
        'https://www.dhanik.in',
        'http://localhost:3000',
        'http://localhost:5173'
    ],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
};
app.use(cors(corsOptions));
app.use(express.json());

// Serve uploaded proof screenshots
const path = require('path');
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/dashboard', require('./routes/dashboardRoutes'));
app.use('/api/token', require('./routes/tokenRoutes'));
app.use('/api/referral', require('./routes/referralRoutes'));
app.use('/api/profile', require('./routes/profileRoutes'));
app.use('/api/support', require('./routes/supportRoutes'));
app.use('/api/admin', require('./routes/adminRoutes'));

// Serve static files from the build folder
const buildPath = path.join(__dirname, '../build');
app.use(express.static(buildPath));

// Catch-all route to serve index.html for any request that doesn't match an API route
app.get('*', (req, res) => {
    res.sendFile(path.join(buildPath, 'index.html'));
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, '0.0.0.0', () => console.log(`Server running on port ${PORT}`));
